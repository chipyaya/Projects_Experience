sudo service mongod start
npm i
npm start
