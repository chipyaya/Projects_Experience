mkdir -p data/db
mongod --dbpath "./data/db"
npm i
node app.js
